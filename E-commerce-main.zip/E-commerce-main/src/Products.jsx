import React from 'react'
import Cards from './Cards'

function Products() {
  return (
    <div>
      <Cards/>
    </div>
  )
}

export default Products
